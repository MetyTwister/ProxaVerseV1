operation = input('''
Napiš jakou početní operaci chceš udělat:
+ pro sčítání
- pro odčítání
* pro násobení
/ pro dělení
''')

x = float(input('Zadej první číslo: '))
y = float(input('Zadej druhé číslo: '))

if operation == '+':
    print('{} + {} = '.format(x, y))
    print(x+y)

elif operation == '-':
    print('{} - {} = '.format(x, y))
    print(x-y)

elif operation == '*':
    print('{} * {} = '.format(x, y))
    print(x*y)

elif operation == '/':
    print('{} / {} = '.format(x, y))
    print(x/y)

else:
    print('Zadal jsi špatnou početní operaci, zkus to znovu!')